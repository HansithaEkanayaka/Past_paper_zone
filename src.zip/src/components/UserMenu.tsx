"use client";

import React, { useRef, useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { useTheme } from "@/context/ThemeContext";
import { createClient } from "@/lib/supabase/client";
import { X } from "lucide-react"; // Import X icon for close button

export default function UserMenu() {
  const { user, refreshUser, signOut } = useAuth();
  const { isDarkMode } = useTheme();
  const [isOpen, setIsOpen] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  // State to control profile modal visibility
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // State for profile form fields, initialized with user data
  const [fullName, setFullName] = useState(user?.user_metadata?.full_name || "");
  const [phoneNumber, setPhoneNumber] = useState(""); // Or initialize from user data
  const [location, setLocation] = useState("");
  const [about, setAbout] = useState("");

  if (!user) return null;

  const name =
    (user.user_metadata?.full_name as string) ||
    (user.user_metadata?.name as string) ||
    user.email?.split("@")[0] ||
    "User";
  const avatarUrl =
    (user.user_metadata?.avatar_url as string | undefined) ||
    (user.user_metadata?.picture as string | undefined);
  const initial = name.charAt(0).toUpperCase();

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setUploadError(null);

    try {
      const supabase = createClient();
      const filePath = `${user.id}/${Date.now()}-${file.name}`;

      const { error: uploadErr } = await supabase.storage
        .from("avatars")
        .upload(filePath, file, { upsert: true });

      if (uploadErr) throw uploadErr;

      const {
        data: { publicUrl },
      } = supabase.storage.from("avatars").getPublicUrl(filePath);

      const { error: updateErr } = await supabase.auth.updateUser({
        data: { avatar_url: publicUrl },
      });

      if (updateErr) throw updateErr;

      await refreshUser();
    } catch (err: any) {
      setUploadError(err.message || "Photo upload failed.");
    } finally {
      setUploading(false);
    }
  };

  // Function to handle saving profile changes
  const handleSaveProfile = async () => {
    try {
        const supabase = createClient();
        const { error } = await supabase.auth.updateUser({
            data: {
                full_name: fullName,
                phone_number: phoneNumber, // Assuming you store this in metadata
                location: location,
                about: about,
            }
        });

        if (error) throw error;
        await refreshUser(); // Update the user context with new data
        setIsProfileModalOpen(false); // Close the modal after saving

    } catch (error: any) {
        console.error("Profile update failed:", error.message);
        // Handle error, perhaps show a notification
    }
  }


  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setIsOpen((v) => !v)}
        className="flex items-center gap-2 rounded-full focus:outline-none focus:ring-2 focus:ring-[#DD6B20]"
      >
        {avatarUrl ? (
          <img
            src={avatarUrl}
            alt={name}
            className="w-8 h-8 rounded-full object-cover border-2 border-[#DD6B20]"
          />
        ) : (
          <div className="w-8 h-8 rounded-full bg-[#DD6B20] text-white flex items-center justify-center font-bold text-sm">
            {initial}
          </div>
        )}
        <span className="hidden lg:inline text-white text-sm font-semibold max-w-[100px] truncate">
          {name}
        </span>
      </button>

      {isOpen && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setIsOpen(false)} />
          <div
            className={`absolute right-0 mt-3 w-64 rounded-2xl border shadow-2xl z-50 p-4 ${
              isDarkMode
                ? "bg-[#1A202C] border-gray-700 text-white"
                : "bg-white border-gray-200 text-gray-900"
            }`}
          >
            <div className="flex items-center gap-3 pb-3 mb-3 border-b border-gray-700/30">
              {avatarUrl ? (
                <img
                  src={avatarUrl}
                  alt={name}
                  className="w-12 h-12 rounded-full object-cover border-2 border-[#DD6B20]"
                />
              ) : (
                <div className="w-12 h-12 rounded-full bg-[#DD6B20] text-white flex items-center justify-center font-bold text-lg">
                  {initial}
                </div>
              )}
              <div className="min-w-0">
                <p className="font-bold text-sm truncate">{name}</p>
                <p className="text-xs text-gray-400 truncate">{user.email}</p>
              </div>
            </div>

            {uploadError && (
              <p className="text-xs text-red-400 mb-2">{uploadError}</p>
            )}

            <button
              type="button"
              onClick={() => {
                setIsOpen(false);
                setIsProfileModalOpen(true); // Open the modal
              }}
              className="block w-full text-left text-xs font-bold px-3 py-2 rounded-xl hover:bg-[#DD6B20]/10 text-[#DD6B20] transition-all"
            >
              View Profile
            </button>

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={uploading}
              className="w-full text-left text-xs font-bold px-3 py-2 rounded-xl hover:bg-[#DD6B20]/10 text-[#DD6B20] transition-all disabled:opacity-50"
            >
              {uploading ? "Uploading..." : "Change Profile Photo"}
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleAvatarChange}
            />

            <button
              type="button"
              onClick={async () => {
                setIsOpen(false);
                await signOut();
              }}
              className="w-full text-left text-xs font-bold px-3 py-2 mt-1 rounded-xl hover:bg-red-500/10 text-red-400 transition-all"
            >
              Log Out
            </button>
          </div>
        </>
      )}

      {/* The Profile Edit Modal */}
      {isProfileModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60">
            <div className="absolute inset-0" onClick={() => setIsProfileModalOpen(false)}></div>
          <div className={`relative w-full max-w-xl rounded-3xl shadow-2xl p-8 max-h-[90vh] overflow-y-auto ${isDarkMode ? "bg-[#1A202C]" : "bg-white"}`}>
            <button onClick={() => setIsProfileModalOpen(false)} className="absolute top-6 right-6 text-gray-400 hover:text-gray-600">
                <X size={24} />
            </button>

            <h2 className="text-3xl font-bold mb-8">My Profile</h2>

            <div className="flex flex-col md:flex-row items-center md:items-start gap-6 mb-8">
                <div className="relative shrink-0">
                    {avatarUrl ? (
                        <img src={avatarUrl} alt={name} className="w-28 h-28 rounded-full object-cover border-4 border-[#DD6B20]" />
                    ) : (
                        <div className="w-28 h-28 rounded-full bg-[#DD6B20] text-white flex items-center justify-center font-bold text-5xl">
                            {initial}
                        </div>
                    )}
                    <button onClick={() => fileInputRef.current?.click()} className="absolute bottom-0 right-0 bg-white p-1.5 rounded-full shadow border border-gray-200 text-gray-500 hover:text-[#DD6B20]">
                        <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
                    </button>
                </div>
                <div className="border border-gray-700/30 p-5 rounded-2xl flex-grow">
                    <p className="text-sm text-[#DD6B20] font-bold uppercase mb-3">CONTACT</p>
                    <div className="flex items-center gap-2 mb-3">
                        <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5 text-gray-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
                        <span className="text-lg font-medium">{user.email}</span>
                    </div>
                    <p className="text-gray-400 text-sm mb-3">Add a phone number or location below and they'll show up here.</p>
                    <p className="text-gray-300 text-sm">Member since {new Date(user.created_at).toLocaleDateString("en-US", { year: 'numeric', month: 'long', day: 'numeric' })}</p>
                </div>
            </div>


            <div className="space-y-5">
                <div>
                    <label htmlFor="fullName" className="block text-sm font-medium text-gray-500 mb-1.5">Full Name</label>
                    <input id="fullName" type="text" value={fullName} onChange={(e) => setFullName(e.target.value)} className={`w-full px-4 py-3 rounded-xl border ${isDarkMode ? "bg-gray-800 border-gray-700" : "bg-gray-50 border-gray-200"} focus:ring-2 focus:ring-[#DD6B20] focus:border-[#DD6B20]`} />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div>
                        <label htmlFor="phoneNumber" className="block text-sm font-medium text-gray-500 mb-1.5">Phone <span className='text-gray-400'>(optional)</span></label>
                        <input id="phoneNumber" type="text" value={phoneNumber} onChange={(e) => setPhoneNumber(e.target.value)} placeholder="07X XXX XXXX" className={`w-full px-4 py-3 rounded-xl border ${isDarkMode ? "bg-gray-800 border-gray-700" : "bg-gray-50 border-gray-200"} focus:ring-2 focus:ring-[#DD6B20] focus:border-[#DD6B20]`} />
                    </div>
                    <div>
                        <label htmlFor="location" className="block text-sm font-medium text-gray-500 mb-1.5">Location <span className='text-gray-400'>(optional)</span></label>
                        <input id="location" type="text" value={location} onChange={(e) => setLocation(e.target.value)} placeholder="City, Sri Lanka" className={`w-full px-4 py-3 rounded-xl border ${isDarkMode ? "bg-gray-800 border-gray-700" : "bg-gray-50 border-gray-200"} focus:ring-2 focus:ring-[#DD6B20] focus:border-[#DD6B20]`} />
                    </div>
                </div>
                <div>
                    <label htmlFor="about" className="block text-sm font-medium text-gray-500 mb-1.5">About <span className='text-gray-400'>(optional)</span></label>
                    <textarea id="about" rows={4} value={about} onChange={(e) => setAbout(e.target.value)} placeholder="Grade, school, subjects you're studying, etc." className={`w-full px-4 py-3 rounded-xl border ${isDarkMode ? "bg-gray-800 border-gray-700" : "bg-gray-50 border-gray-200"} focus:ring-2 focus:ring-[#DD6B20] focus:border-[#DD6B20]`}></textarea>
                </div>

            </div>

            <button onClick={handleSaveProfile} className="w-full mt-10 bg-[#DD6B20] hover:bg-[#C05621] text-white font-bold py-4 px-6 rounded-2xl transition-all text-lg">
                Save Changes
            </button>
          </div>
        </div>
      )}
    </div>
  );
}