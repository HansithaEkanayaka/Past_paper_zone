"use client";

import React, { useEffect, useState } from "react";
import { useTheme } from "@/context/ThemeContext";

// 2026 GCE O/L Examination: 8 - 17 December 2026 (Department of Examinations,
// Sri Lanka). Midnight in Sri Lanka is UTC+5:30, so build the target date
// from a fixed ISO offset rather than `new Date(2026, 11, 8)`, which would
// use the visitor's own local timezone instead.
const EXAM_START = new Date("2026-12-08T00:00:00+05:30");

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  done: boolean;
}

function getTimeLeft(): TimeLeft {
  const diff = EXAM_START.getTime() - Date.now();
  if (diff <= 0) {
    return { days: 0, hours: 0, minutes: 0, seconds: 0, done: true };
  }
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
  const minutes = Math.floor((diff / (1000 * 60)) % 60);
  const seconds = Math.floor((diff / 1000) % 60);
  return { days, hours, minutes, seconds, done: false };
}

export default function ExamCountdown() {
  const { isDarkMode } = useTheme();
  const [timeLeft, setTimeLeft] = useState<TimeLeft | null>(null);

  useEffect(() => {
    setTimeLeft(getTimeLeft());
    const interval = setInterval(() => setTimeLeft(getTimeLeft()), 1000);
    return () => clearInterval(interval);
  }, []);

  const units: { label: string; value: number }[] = timeLeft
    ? [
        { label: "Days", value: timeLeft.days },
        { label: "Hours", value: timeLeft.hours },
        { label: "Minutes", value: timeLeft.minutes },
        { label: "Seconds", value: timeLeft.seconds },
      ]
    : [
        { label: "Days", value: 0 },
        { label: "Hours", value: 0 },
        { label: "Minutes", value: 0 },
        { label: "Seconds", value: 0 },
      ];

  return (
    <section
      className={`w-full py-10 px-6 md:px-16 border-b transition-colors duration-300 ${
        isDarkMode ? "bg-[#171923] border-gray-800" : "bg-[#1A365D] border-gray-800"
      }`}
    >
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="text-center md:text-left">
          <span className="text-xs font-bold text-[#DD6B20] bg-orange-500/10 px-4 py-1.5 rounded-full border border-orange-500/30 uppercase tracking-wider">
            Countdown
          </span>
          <h2 className="font-brand text-2xl md:text-3xl font-extrabold text-white mt-3">
            {timeLeft?.done
              ? "The 2026 O/L Exam has begun — All the best!"
              : "Time left until the 2026 G.C.E. O/L Exam"}
          </h2>
          <p className="text-sm text-gray-300 mt-1">8 – 17 December 2026</p>
        </div>

        {!timeLeft?.done && (
          <div className="flex items-center gap-3 sm:gap-4">
            {units.map((unit) => (
              <div
                key={unit.label}
                className="flex flex-col items-center justify-center bg-white/10 backdrop-blur-sm rounded-2xl w-16 sm:w-20 py-3 border border-white/10"
              >
                <span className="text-2xl sm:text-3xl font-black text-white font-mono tabular-nums">
                  {unit.value.toString().padStart(2, "0")}
                </span>
                <span className="text-[10px] sm:text-xs font-semibold text-gray-300 uppercase tracking-wide mt-1">
                  {unit.label}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
