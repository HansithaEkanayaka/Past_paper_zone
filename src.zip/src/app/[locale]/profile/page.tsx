"use client";

import React from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Link } from "@/i18n/navigation";
import { useAuth } from "@/context/AuthContext";
import { useTheme } from "@/context/ThemeContext";

export default function ProfilePage() {
  const { user, loading, openLoginModal } = useAuth();
  const { isDarkMode } = useTheme();

  const name =
    (user?.user_metadata?.full_name as string) ||
    (user?.user_metadata?.name as string) ||
    user?.email?.split("@")[0] ||
    "User";
  const avatarUrl =
    (user?.user_metadata?.avatar_url as string | undefined) ||
    (user?.user_metadata?.picture as string | undefined);
  const initial = name.charAt(0).toUpperCase();
  const joinedDate = user?.created_at
    ? new Date(user.created_at).toLocaleDateString(undefined, {
        year: "numeric",
        month: "long",
        day: "numeric",
      })
    : null;

  return (
    <div
      className={`flex flex-col min-h-screen transition-colors duration-300 ${
        isDarkMode ? "bg-[#171923] text-white" : "bg-gray-50 text-gray-900"
      }`}
    >
      <Header />

      <main className="flex-1 w-full max-w-2xl mx-auto py-16 px-6">
        {loading ? (
          <p className="text-center text-sm opacity-70">Loading...</p>
        ) : !user ? (
          <div
            className={`rounded-2xl border p-10 text-center ${
              isDarkMode ? "bg-[#2D3748] border-gray-700" : "bg-white border-gray-200"
            }`}
          >
            <p className="mb-4 text-base font-medium">
              You need to be logged in to view your profile.
            </p>
            <button
              type="button"
              onClick={() => openLoginModal()}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#DD6B20] hover:bg-orange-600 text-white font-bold text-sm transition-all"
            >
              Log In
            </button>
          </div>
        ) : (
          <div
            className={`rounded-2xl border p-8 md:p-10 ${
              isDarkMode ? "bg-[#2D3748] border-gray-700" : "bg-white border-gray-200"
            }`}
          >
            <div className="flex items-center gap-5 mb-8">
              {avatarUrl ? (
                <img
                  src={avatarUrl}
                  alt={name}
                  className="w-20 h-20 rounded-full object-cover border-4 border-[#DD6B20]"
                />
              ) : (
                <div className="w-20 h-20 rounded-full bg-[#DD6B20] text-white flex items-center justify-center font-bold text-3xl">
                  {initial}
                </div>
              )}
              <div>
                <h1 className="text-2xl font-extrabold">{name}</h1>
                <p className={`text-sm ${isDarkMode ? "text-gray-400" : "text-gray-500"}`}>
                  {user.email}
                </p>
              </div>
            </div>

            <dl className="space-y-4 text-sm">
              <div className="flex justify-between border-b pb-3 border-gray-700/20">
                <dt className="font-semibold opacity-70">Full Name</dt>
                <dd>{name}</dd>
              </div>
              <div className="flex justify-between border-b pb-3 border-gray-700/20">
                <dt className="font-semibold opacity-70">Email</dt>
                <dd>{user.email}</dd>
              </div>
              {joinedDate && (
                <div className="flex justify-between pb-1">
                  <dt className="font-semibold opacity-70">Member Since</dt>
                  <dd>{joinedDate}</dd>
                </div>
              )}
            </dl>

            <Link
              href="/"
              className="mt-8 inline-flex items-center gap-2 text-sm font-bold text-[#DD6B20] hover:underline"
            >
              ← Back to PastPaperZone
            </Link>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
